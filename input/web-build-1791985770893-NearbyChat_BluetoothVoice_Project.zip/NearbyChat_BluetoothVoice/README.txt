Nearby Bluetooth Voice — starter Android Studio project

This is a separate Bluetooth Classic RFCOMM voice-call prototype, based on the package and project setup from your original Nearby Chat Kotlin files. It does not use Nearby Connections, Wi-Fi, mobile data, SIM service, or internet for the call audio.

How to test:
1. Build and install the same APK on both Android phones.
2. Pair both phones in Android Bluetooth settings.
3. On Phone A, open app and tap “Wait for call (Host)”. Keep app open.
4. On Phone B, tap “Refresh paired phones”, select Phone A, then tap “Call selected phone”.
5. Accept Bluetooth connection if Android asks. Try speaker/mute/end call.

Notes:
- Both phones must support Bluetooth Classic RFCOMM and grant microphone/Bluetooth permissions.
- Bluetooth audio can have noticeable delay and limited quality/range. Some phone models may behave differently.
- This is a prototype. It has not been compiled or tested on physical devices in this environment. Do not rely on it for emergency calls.
- Target SDK is 32 to keep Android 12 runtime Bluetooth permissions straightforward. The app still requests runtime BLUETOOTH_CONNECT and microphone permissions.
