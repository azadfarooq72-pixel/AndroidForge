package com.example.nearbychat

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var manager: BluetoothVoiceManager
    private var devices: List<BluetoothDevice> = emptyList()
    private var pending: (() -> Unit)? = null

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) pending?.invoke() else status.text = "Bluetooth and microphone permissions are required."
        pending = null
    }

    private fun askPermissions(action: () -> Unit) {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
        pending = action
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { pending = null; action() } else permissions.launch(missing.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        status = TextView(this).apply { text = "Pair phones in Android Bluetooth settings first."; textSize = 16f }
        deviceSpinner = Spinner(this)
        val refresh = Button(this).apply { text = "Refresh paired phones" }
        val host = Button(this).apply { text = "Wait for call (Host)" }
        val call = Button(this).apply { text = "Call selected phone" }
        val mute = Button(this).apply { text = "Mute / Unmute" }
        val speaker = Button(this).apply { text = "Speaker / Earpiece" }
        val end = Button(this).apply { text = "End Call" }
        val note = TextView(this).apply { text = "Bluetooth-only voice. No SIM, mobile data, Wi-Fi, or internet is used. Keep phones close. Audio quality/range may be limited." }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32)
            addView(TextView(this@MainActivity).apply { text = "Nearby Bluetooth Voice"; textSize = 23f })
            addView(status); addView(refresh); addView(deviceSpinner); addView(host); addView(call); addView(mute); addView(speaker); addView(end); addView(note)
        }
        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams(-1, -2)) })
        manager = BluetoothVoiceManager(this) { message -> runOnUiThread { status.text = message } }
        refresh.setOnClickListener { askPermissions { loadPairedDevices() } }
        host.setOnClickListener { askPermissions { manager.host() } }
        call.setOnClickListener { askPermissions {
            val device = devices.getOrNull(deviceSpinner.selectedItemPosition)
            if (device == null) status.text = "No paired phone selected. Tap Refresh paired phones."
            else manager.call(device)
        } }
        mute.setOnClickListener { manager.toggleMute() }
        speaker.setOnClickListener { manager.toggleSpeaker() }
        end.setOnClickListener { manager.endCall() }
        refresh.post { askPermissions { loadPairedDevices() } }
    }

    @Suppress("MissingPermission")
    private fun loadPairedDevices() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { status.text = "This phone has no Bluetooth adapter."; return }
        if (!adapter.isEnabled) { status.text = "Turn Bluetooth on in Android Settings."; return }
        devices = try { adapter.bondedDevices.toList().sortedBy { it.name ?: it.address } } catch (_: SecurityException) { emptyList() }
        deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            devices.map { "${it.name ?: "Bluetooth phone"} (${it.address})" })
        status.text = if (devices.isEmpty()) "No paired phones found. Pair the phones in Android settings." else "${devices.size} paired device(s) ready."
    }

    override fun onDestroy() { if (::manager.isInitialized) manager.close(); super.onDestroy() }
}
