package com.example.nearbychat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class BluetoothVoiceManager(private val context: Context, private val onStatus: (String) -> Unit) {
    companion object {
        private val APP_UUID: UUID = UUID.fromString("5d8b6f4e-2e2c-4a2f-9c51-2b5a7d9f0c31")
        private const val SAMPLE_RATE = 16000
        private const val CHUNK_BYTES = 640 // 20 ms, mono PCM16
    }
    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var server: BluetoothServerSocket? = null
    private val running = AtomicBoolean(false)
    private val muted = AtomicBoolean(false)
    private val speakerOn = AtomicBoolean(true)
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var player: AudioTrack? = null

    @SuppressLint("MissingPermission")
    fun host() {
        if (running.get()) { onStatus("Already in a call or connecting."); return }
        thread(name = "BluetoothVoiceHost") {
            try {
                onStatus("Waiting for a paired phone to call...")
                server = adapter?.listenUsingRfcommWithServiceRecord("Nearby Bluetooth Voice", APP_UUID)
                    ?: throw IOException("Bluetooth is not available")
                val accepted = server!!.accept()
                socket = accepted
                server?.close(); server = null
                startAudio(accepted)
            } catch (e: Exception) { if (!running.get()) onStatus("Host failed: ${e.message ?: "connection error"}") else onStatus("Call ended: ${e.message}") ; closeConnection() }
        }
    }

    @SuppressLint("MissingPermission")
    fun call(device: BluetoothDevice) {
        if (running.get()) { onStatus("Already in a call or connecting."); return }
        thread(name = "BluetoothVoiceCall") {
            try {
                onStatus("Connecting to ${device.name ?: "paired phone"}...")
                adapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(APP_UUID)
                s.connect()
                socket = s
                startAudio(s)
            } catch (e: Exception) { onStatus("Call failed: ${e.message ?: "connection error"}"); closeConnection() }
        }
    }

    private fun startAudio(s: BluetoothSocket) {
        running.set(true)
        val minIn = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) throw IOException("Audio format is not supported")
        val input = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, CHUNK_BYTES * 4))
        val output = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SAMPLE_RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minOut, CHUNK_BYTES * 4)).setTransferMode(AudioTrack.MODE_STREAM).build()
        recorder = input; player = output
        try {
            input.startRecording(); output.play(); applySpeaker()
            onStatus("VOICE CALL CONNECTED — Bluetooth only")
            thread(name = "BluetoothMicToSocket") {
                val buffer = ByteArray(CHUNK_BYTES)
                try {
                    val out = s.outputStream
                    while (running.get()) {
                        var offset = 0
                        while (offset < buffer.size && running.get()) {
                            val count = input.read(buffer, offset, buffer.size - offset)
                            if (count < 0) throw IOException("Microphone read failed")
                            offset += count
                        }
                        if (running.get() && offset == buffer.size) {
                            if (muted.get()) buffer.fill(0)
                            out.write(buffer); out.flush()
                        }
                    }
                } catch (_: Exception) { if (running.get()) onStatus("Bluetooth audio disconnected") ; endCall() }
            }
            val ins = s.inputStream
            val frame = ByteArray(CHUNK_BYTES)
            while (running.get()) {
                var offset = 0
                while (offset < frame.size) {
                    val n = ins.read(frame, offset, frame.size - offset)
                    if (n == -1) throw IOException("Other phone disconnected")
                    offset += n
                }
                output.write(frame, 0, frame.size)
            }
        } finally { input.release(); output.release(); recorder = null; player = null; closeConnection() }
    }

    fun toggleMute() { val now = !muted.get(); muted.set(now); onStatus(if (running.get()) if (now) "Call connected — microphone muted" else "Call connected — microphone on" else "Not in a call") }
    fun toggleSpeaker() { val now = !speakerOn.get(); speakerOn.set(now); applySpeaker(); onStatus(if (running.get()) if (now) "Call connected — speaker mode" else "Call connected — earpiece mode" else "Not in a call") }
    private fun applySpeaker() { try { val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager; am.mode = AudioManager.MODE_IN_COMMUNICATION; am.isSpeakerphoneOn = speakerOn.get() } catch (_: Exception) {} }
    fun endCall() { running.set(false); try { socket?.close() } catch (_: Exception) {}; try { server?.close() } catch (_: Exception) {}; try { recorder?.stop() } catch (_: Exception) {}; try { player?.pause() } catch (_: Exception) {}; onStatus("Call ended") }
    private fun closeConnection() { running.set(false); try { socket?.close() } catch (_: Exception) {}; try { server?.close() } catch (_: Exception) {}; socket = null; server = null; try { (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode = AudioManager.MODE_NORMAL } catch (_: Exception) {} }
    fun close() { endCall(); closeConnection() }
}
