plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.nearbychat"
    compileSdk = 35
    defaultConfig { applicationId = "com.example.nearbychat"; minSdk = 26; targetSdk = 32; versionCode = 2; versionName = "2.0-bluetooth-voice" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0"); implementation("androidx.activity:activity-ktx:1.9.3") }
