Nearby Chat - Android Studio project

What it does:
- Host: advertises this phone for a nearby peer-to-peer connection.
- Join: searches for another Nearby Chat phone.
- Send: sends text messages over Google Nearby Connections.

How to open:
1. Extract this ZIP.
2. Open Android Studio.
3. Choose Open and select the NearbyChat folder.
4. Allow Gradle to sync and install any requested Android SDK components.
5. Run on two Android phones. Both phones need Google Play services.

Important:
- This is a starter project based on the supplied Kotlin files, not a verified compiled APK.
- Nearby connections require compatible Google Play services and runtime permissions.
- The current sample auto-accepts incoming connections; use only with trusted nearby devices.
