package com.example.nearbychat

import android.content.Context
import android.os.Build
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

class NearbyManager(
    context: Context,
    private val onStatus: (String) -> Unit,
    private val onMessage: (String) -> Unit,
) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = "com.example.nearbychat"
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private val myName = Build.MODEL
    private var endpointId: String? = null

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            payload.asBytes()?.let { onMessage("Them: " + String(it, Charsets.UTF_8)) }
        }
        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // Auto-accepting for the demo. For a real app, show info.authenticationDigits
            // on both phones and let each user confirm they match.
            client.acceptConnection(id, payloadCallback)
            onStatus("Connecting to ${info.endpointName}...")
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                endpointId = id
                client.stopAdvertising()
                client.stopDiscovery()
                onStatus("Connected")
            } else {
                onStatus("Connection failed")
            }
        }

        override fun onDisconnected(id: String) {
            endpointId = null
            onStatus("Disconnected")
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            client.requestConnection(myName, id, connectionCallback)
        }
        override fun onEndpointLost(id: String) {}
    }

    /** Phone A taps this. */
    fun startHosting() {
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(myName, serviceId, connectionCallback, options)
            .addOnSuccessListener { onStatus("Waiting for a nearby phone...") }
            .addOnFailureListener { onStatus("Host failed: ${it.message}") }
    }

    /** Phone B taps this. */
    fun startJoining() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, discoveryCallback, options)
            .addOnSuccessListener { onStatus("Searching...") }
            .addOnFailureListener { onStatus("Search failed: ${it.message}") }
    }

    fun send(text: String) {
        val id = endpointId ?: return
        client.sendPayload(id, Payload.fromBytes(text.toByteArray(Charsets.UTF_8)))
        onMessage("Me: $text")
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        endpointId = null
    }
}
