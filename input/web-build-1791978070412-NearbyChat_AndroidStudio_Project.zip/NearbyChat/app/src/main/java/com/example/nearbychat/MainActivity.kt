package com.example.nearbychat

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var nearby: NearbyManager
    private lateinit var status: TextView
    private lateinit var log: TextView
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) pendingAction?.invoke()
            else status.text = "Permissions needed"
            pendingAction = null
        }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.NEARBY_WIFI_DEVICES,
        )
        Build.VERSION.SDK_INT >= 31 -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION,
        )
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun withPermissions(action: () -> Unit) {
        pendingAction = action
        permissionLauncher.launch(requiredPermissions())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { text = "Not connected"; textSize = 16f }
        log = TextView(this)
        val scroll = ScrollView(this).apply {
            addView(log)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val hostBtn = Button(this).apply { text = "Host" }
        val joinBtn = Button(this).apply { text = "Join" }
        val input = EditText(this).apply { hint = "Message" }
        val sendBtn = Button(this).apply { text = "Send" }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(hostBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(joinBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val sendRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendBtn)
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
            addView(status)
            addView(buttons)
            addView(scroll)
            addView(sendRow)
        })

        nearby = NearbyManager(
            this,
            onStatus = { runOnUiThread { status.text = it } },
            onMessage = { runOnUiThread { log.append(it + "\n") } },
        )

        hostBtn.setOnClickListener { withPermissions { nearby.startHosting() } }
        joinBtn.setOnClickListener { withPermissions { nearby.startJoining() } }
        sendBtn.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) { nearby.send(text); input.setText("") }
        }
    }

    override fun onDestroy() {
        nearby.stop()
        super.onDestroy()
    }
}
