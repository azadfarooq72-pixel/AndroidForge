package com.example.nearbychat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class HubViewModel(app: Application) : AndroidViewModel(app), AzadNearby.Listener {

    private val _peers = MutableStateFlow<List<Peer>>(emptyList())
    val peers: StateFlow<List<Peer>> = _peers.asStateFlow()

    private val _status = MutableStateFlow("Radar off")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    private val _speaker = MutableStateFlow(false)
    val speaker: StateFlow<Boolean> = _speaker.asStateFlow()

    private val nearby = AzadNearby(app, this)

    fun toggle() {
        if (_scanning.value) {
            nearby.stop()
            _peers.value = emptyList()
            _scanning.value = false
            _status.value = "Radar off"
        } else {
            _scanning.value = true
            nearby.start()
        }
    }

    fun connect(id: String) = nearby.connect(id)
    fun hangUp(id: String) = nearby.hangUp(id)
    fun setStatus(text: String) { _status.value = text }

    fun toggleMute() { _muted.value = !_muted.value; nearby.setMuted(_muted.value) }
    fun toggleSpeaker() { _speaker.value = !_speaker.value; nearby.setSpeaker(_speaker.value) }

    override fun onPeerUpdate(peer: Peer) = _peers.update { l -> l.filter { it.id != peer.id } + peer }
    override fun onPeerLost(id: String) = _peers.update { l -> l.filter { it.id != id } }
    override fun onStatus(text: String) { _status.value = text }
    override fun onCall(active: Boolean) {
        if (!active) { _muted.value = false; _speaker.value = false }
    }

    override fun onCleared() { nearby.stop() }
}
