package com.example.nearbychat

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/** G.711 mu-law: 16-bit sample <-> 8-bit byte. Pure Kotlin, no libraries. */
object Mulaw {
    private const val BIAS = 0x84
    private const val CLIP = 32635

    fun encode(s: Short): Byte {
        var x = s.toInt()
        val sign = if (x < 0) { x = -x; 0x80 } else 0
        if (x > CLIP) x = CLIP
        x += BIAS
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (x and mask) == 0) { exp--; mask = mask shr 1 }
        val mant = (x shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or mant).inv().toByte()
    }

    fun decode(b: Byte): Short {
        val u = b.toInt().inv() and 0xFF
        val exp = (u shr 4) and 0x07
        val mant = u and 0x0F
        val t = (((mant shl 3) + BIAS) shl exp) - BIAS
        return (if (u and 0x80 != 0) -t else t).toShort()
    }
}

/**
 * Captures the mic, sends small frames through [onFrame], and plays frames
 * you pass to [onReceive]. 8 kHz mu-law = about 64 kbps.
 */
class VoiceEngine(context: Context, private val onFrame: (ByteArray) -> Unit) {

    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val rate = AzadConfig.SAMPLE_RATE
    private val frameSamples = rate * AzadConfig.FRAME_MS / 1000
    private val queue = LinkedBlockingQueue<ByteArray>()

    @Volatile private var running = false
    @Volatile var muted = false

    fun start() {
        if (running) return
        running = true
        muted = false
        queue.clear()
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        setSpeaker(false)
        Thread({ captureLoop() }, "azad-capture").start()
        Thread({ playLoop() }, "azad-play").start()
    }

    fun stop() {
        running = false
        queue.clear()
        audio.mode = AudioManager.MODE_NORMAL
        setSpeaker(false)
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) { audio.isSpeakerphoneOn = on }

    /** Call this with every voice frame received from the other phone. */
    fun onReceive(frame: ByteArray) {
        while (queue.size >= AzadConfig.MAX_BUFFERED_FRAMES) queue.poll() // drop oldest to stay live
        queue.offer(frame)
    }

    @SuppressLint("MissingPermission")
    private fun captureLoop() {
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, // enables echo cancellation where available
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, frameSamples * 2 * 4),
            )
        } catch (e: Exception) { return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }

        val pcm = ShortArray(frameSamples)
        try {
            rec.startRecording()
            while (running) {
                var got = 0
                while (got < frameSamples && running) {
                    val n = rec.read(pcm, got, frameSamples - got)
                    if (n < 0) return
                    got += n
                }
                if (!running || muted) continue
                val out = ByteArray(frameSamples) { Mulaw.encode(pcm[it]) }
                onFrame(out)
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
    }

    private fun playLoop() {
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, frameSamples * 2 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val pcm = ShortArray(frameSamples)
        try {
            track.play()
            while (running) {
                val frame = queue.poll(AzadConfig.FRAME_MS * 2L, TimeUnit.MILLISECONDS) ?: continue
                val n = min(frame.size, frameSamples)
                for (i in 0 until n) pcm[i] = Mulaw.decode(frame[i])
                track.write(pcm, 0, n)
            }
        } finally {
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }
    }
}
