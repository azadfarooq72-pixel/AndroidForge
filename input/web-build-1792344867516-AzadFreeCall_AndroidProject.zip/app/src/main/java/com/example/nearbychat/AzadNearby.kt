package com.example.nearbychat

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

enum class PeerState { FOUND, CONNECTING, CONNECTED }
data class Peer(val id: String, val callsign: String, val state: PeerState = PeerState.FOUND)

/** Bluetooth broadcast + scan + one live voice call at a time. */
class AzadNearby(context: Context, private val listener: Listener) {

    interface Listener {
        fun onPeerUpdate(peer: Peer)
        fun onPeerLost(id: String)
        fun onStatus(text: String)
        fun onCall(active: Boolean)
    }

    private val client = Nearby.getConnectionsClient(context)
    private val names = mutableMapOf<String, String>()
    private val connected = mutableSetOf<String>()
    @Volatile private var activeId: String? = null

    private val voice = VoiceEngine(context) { frame ->
        activeId?.let { client.sendPayload(it, Payload.fromBytes(frame)) }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            payload.asBytes()?.let { voice.onReceive(it) }
        }
        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // Demo: auto-accept. Before release, show info.authenticationDigits on both
            // phones and let each user confirm they match, to block eavesdroppers.
            names[id] = info.endpointName
            client.acceptConnection(id, payloadCallback)
            listener.onPeerUpdate(Peer(id, info.endpointName, PeerState.CONNECTING))
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            val name = names[id] ?: "Unknown"
            if (!result.status.isSuccess) {
                listener.onPeerUpdate(Peer(id, name, PeerState.FOUND))
                listener.onStatus("Link failed")
                return
            }
            if (activeId != null && activeId != id) { // already on a call
                client.disconnectFromEndpoint(id)
                listener.onPeerLost(id)
                return
            }
            connected += id
            activeId = id
            voice.start()
            listener.onPeerUpdate(Peer(id, name, PeerState.CONNECTED))
            listener.onCall(true)
            listener.onStatus("On call with $name")
        }

        override fun onDisconnected(id: String) = endCall(id, "Call ended")
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            names[id] = info.endpointName
            listener.onPeerUpdate(Peer(id, info.endpointName))
        }
        override fun onEndpointLost(id: String) {
            if (id !in connected) listener.onPeerLost(id)
        }
    }

    private fun endCall(id: String, message: String) {
        connected -= id
        listener.onPeerLost(id)
        if (activeId == id) {
            activeId = null
            voice.stop()
            listener.onCall(false)
        }
        listener.onStatus(message)
    }

    fun start() {
        stop()
        val strategy = Strategy.P2P_CLUSTER
        val adv = AdvertisingOptions.Builder().setStrategy(strategy).setLowPower(AzadConfig.BLUETOOTH_ONLY).build()
        val dis = DiscoveryOptions.Builder().setStrategy(strategy).setLowPower(AzadConfig.BLUETOOTH_ONLY).build()

        client.startAdvertising(AzadConfig.callsign, AzadConfig.SERVICE_ID, connectionCallback, adv)
            .addOnFailureListener { listener.onStatus("Broadcast failed: ${it.message}") }
        client.startDiscovery(AzadConfig.SERVICE_ID, discoveryCallback, dis)
            .addOnSuccessListener { listener.onStatus("Scanning as ${AzadConfig.callsign}") }
            .addOnFailureListener { listener.onStatus("Scan failed: ${it.message}") }
    }

    /** Tap CONNECT: links to the peer and the call starts on both phones. */
    fun connect(id: String) {
        listener.onPeerUpdate(Peer(id, names[id] ?: "Unknown", PeerState.CONNECTING))
        client.requestConnection(AzadConfig.callsign, id, connectionCallback)
            .addOnFailureListener { listener.onStatus("Connect failed: ${it.message}") }
    }

    fun hangUp(id: String) {
        client.disconnectFromEndpoint(id)
        endCall(id, "Call ended")
    }

    fun setMuted(muted: Boolean) { voice.muted = muted }
    fun setSpeaker(on: Boolean) = voice.setSpeaker(on)

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connected.clear()
        if (activeId != null) { activeId = null; voice.stop(); listener.onCall(false) }
    }
}
