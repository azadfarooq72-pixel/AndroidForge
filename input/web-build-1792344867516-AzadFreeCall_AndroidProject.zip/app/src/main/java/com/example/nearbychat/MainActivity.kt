package com.example.nearbychat

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

class MainActivity : ComponentActivity() {

    private val vm: HubViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) vm.toggle()
            else vm.setStatus("Bluetooth and microphone permissions needed")
        }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.NEARBY_WIFI_DEVICES,
            Manifest.permission.RECORD_AUDIO,
        )
        Build.VERSION.SDK_INT >= 31 -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
        )
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECORD_AUDIO)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val peers by vm.peers.collectAsState()
            val status by vm.status.collectAsState()
            val scanning by vm.scanning.collectAsState()
            val muted by vm.muted.collectAsState()
            val speaker by vm.speaker.collectAsState()

            ScanningHub(
                peers = peers,
                status = status,
                scanning = scanning,
                muted = muted,
                speaker = speaker,
                onToggle = { if (scanning) vm.toggle() else permissionLauncher.launch(requiredPermissions()) },
                onConnect = vm::connect,
                onHangUp = vm::hangUp,
                onMute = vm::toggleMute,
                onSpeaker = vm::toggleSpeaker,
            )
        }
    }
}
