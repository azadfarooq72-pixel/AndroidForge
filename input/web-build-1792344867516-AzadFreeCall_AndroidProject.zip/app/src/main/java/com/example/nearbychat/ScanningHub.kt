package com.example.nearbychat

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private val CanvasBg = AzadConfig.CanvasBg
private val SurfaceBg = AzadConfig.SurfaceBg
private val Metal = AzadConfig.Metal
private val Cyan = AzadConfig.Cyan
private val Blue = AzadConfig.Blue
private val Green = AzadConfig.Green
private val Red = AzadConfig.Red
private val Mono = FontFamily.Monospace

@Composable
fun ScanningHub(
    peers: List<Peer>,
    status: String,
    scanning: Boolean,
    muted: Boolean,
    speaker: Boolean,
    onToggle: () -> Unit,
    onConnect: (String) -> Unit,
    onHangUp: (String) -> Unit,
    onMute: () -> Unit,
    onSpeaker: () -> Unit,
) {
    val activePeer = peers.firstOrNull { it.state == PeerState.CONNECTED }

    Column(
        Modifier
            .fillMaxSize()
            .background(CanvasBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(AzadConfig.APP_NAME, color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("OFFLINE", Metal)
                Chip("ENCRYPTED", Green)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(AzadConfig.TAGLINE, color = Metal, fontFamily = Mono, fontSize = 11.sp)
        Text(status, color = if (scanning) Cyan else Metal, fontFamily = Mono, fontSize = 12.sp)

        if (activePeer != null) {
            Spacer(Modifier.height(10.dp))
            CallPanel(
                name = activePeer.callsign, muted = muted, speaker = speaker,
                onMute = onMute, onSpeaker = onSpeaker, onEnd = { onHangUp(activePeer.id) },
            )
        }

        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Radar(peers, scanning, Modifier.fillMaxWidth(if (activePeer != null) 0.5f else 0.8f))
        }

        if (peers.isEmpty()) {
            Text(
                if (scanning) "No one in range yet. Move closer." else "Start the radar to find people nearby.",
                color = Metal, fontFamily = Mono, fontSize = 12.sp,
                modifier = Modifier.weight(1f).padding(top = 8.dp),
            )
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(peers, key = { it.id }) { PeerRow(it, onConnect, onHangUp) }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onToggle,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (scanning) Cyan else Metal, contentColor = CanvasBg),
        ) {
            Text(if (scanning) "STOP RADAR" else "START SCAN / BROADCAST", fontFamily = Mono, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CallPanel(
    name: String, muted: Boolean, speaker: Boolean,
    onMute: () -> Unit, onSpeaker: () -> Unit, onEnd: () -> Unit,
) {
    var seconds by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); seconds++ } }

    Column(
        Modifier
            .fillMaxWidth()
            .background(SurfaceBg, RoundedCornerShape(14.dp))
            .border(1.dp, Green, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text("ON CALL", color = Green, fontFamily = Mono, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(name, color = Color.White, fontFamily = Mono, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("%02d:%02d".format(seconds / 60, seconds % 60), color = Green, fontFamily = Mono, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton(if (muted) "UNMUTE" else "MUTE", if (muted) Cyan else Metal, onMute)
            SmallButton(if (speaker) "EARPIECE" else "SPEAKER", if (speaker) Cyan else Metal, onSpeaker)
            SmallButton("END", Red, onEnd)
        }
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 10.sp, fontFamily = Mono,
        modifier = Modifier
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

@Composable
private fun PeerRow(peer: Peer, onConnect: (String) -> Unit, onHangUp: (String) -> Unit) {
    val stateColor = when (peer.state) {
        PeerState.FOUND -> Cyan
        PeerState.CONNECTING -> Blue
        PeerState.CONNECTED -> Green
    }
    Row(
        Modifier.fillMaxWidth().background(SurfaceBg, RoundedCornerShape(12.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(peer.callsign, color = Color.White, fontFamily = Mono, fontWeight = FontWeight.Bold)
            Text(peer.state.name, color = stateColor, fontFamily = Mono, fontSize = 11.sp)
        }
        when (peer.state) {
            PeerState.FOUND -> SmallButton("CALL", Cyan) { onConnect(peer.id) }
            PeerState.CONNECTING -> Text("...", color = Blue, fontFamily = Mono)
            PeerState.CONNECTED -> SmallButton("HANG UP", Red) { onHangUp(peer.id) }
        }
    }
}

@Composable
private fun SmallButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = CanvasBg),
    ) { Text(label, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun Radar(peers: List<Peer>, scanning: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "sweep")
    val angle by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(AzadConfig.SWEEP_MS, easing = LinearEasing), RepeatMode.Restart),
        label = "angle",
    )

    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f
        val trail = AzadConfig.SWEEP_TRAIL

        listOf(1f / 3f, 2f / 3f, 1f).forEach {
            drawCircle(Blue.copy(alpha = 0.45f), radius = r * it, center = c, style = Stroke(2f))
        }
        drawLine(Blue.copy(alpha = 0.25f), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.5f)
        drawLine(Blue.copy(alpha = 0.25f), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.5f)

        if (scanning) {
            for (i in 0..trail) {
                rotate(degrees = angle - i * 1.5f, pivot = c) {
                    drawLine(Cyan.copy(alpha = (1f - i / trail.toFloat()) * 0.5f), c, Offset(c.x + r, c.y), strokeWidth = 3f)
                }
            }
        }

        // Placeholder positions: Nearby Connections gives no signal strength.
        peers.forEach { p ->
            val h = p.id.hashCode()
            val a = (abs(h) % 360) * PI / 180.0
            val d = r * (0.35f + (abs(h / 360) % 55) / 100f)
            val pos = Offset(c.x + (d * cos(a)).toFloat(), c.y + (d * sin(a)).toFloat())
            val col = when (p.state) {
                PeerState.FOUND -> Cyan
                PeerState.CONNECTING -> Blue
                PeerState.CONNECTED -> Green
            }
            drawCircle(col.copy(alpha = 0.25f), radius = 18f, center = pos)
            drawCircle(col, radius = 8f, center = pos)
        }
        drawCircle(Green, radius = 7f, center = c)
    }
}
