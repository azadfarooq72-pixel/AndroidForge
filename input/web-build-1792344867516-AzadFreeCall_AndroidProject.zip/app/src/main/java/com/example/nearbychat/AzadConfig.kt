package com.example.nearbychat

import android.os.Build
import androidx.compose.ui.graphics.Color

/**
 * EDIT THIS FILE to change how the app looks, sounds and behaves.
 * Everything else reads from here.
 */
object AzadConfig {

    // ---------- Identity ----------
    const val APP_NAME = "AZAD FREE CALL"
    const val TAGLINE = "No internet needed · range ~30-100 m"
    const val SERVICE_ID = "com.azad.freecall"   // both phones must use the same value
    var callsign: String = Build.MODEL            // change to any nickname, e.g. "Falcon"

    // ---------- Colors ----------
    val CanvasBg = Color(0xFF0B0E14)   // app background
    val SurfaceBg = Color(0xFF151A22)  // cards
    val Metal = Color(0xFF9AA4B2)      // secondary text
    val Cyan = Color(0xFF00E5FF)       // scanning / primary
    val Blue = Color(0xFF2979FF)       // rings / connecting
    val Green = Color(0xFF39FF88)      // connected / active call
    val Red = Color(0xFFFF4D4D)        // hang up

    // ---------- Radar ----------
    const val SWEEP_MS = 3000          // one full radar rotation
    const val SWEEP_TRAIL = 30         // length of the fading trail

    // ---------- Radio ----------
    const val BLUETOOTH_ONLY = true    // true = never upgrade to Wi-Fi Direct

    // ---------- Audio ----------
    const val SAMPLE_RATE = 8000       // 8000 = phone quality. 16000 = clearer, double the data
    const val FRAME_MS = 20            // audio chunk size; smaller = lower delay, more packets
    const val MAX_BUFFERED_FRAMES = 8  // jitter cap: 8 x 20 ms = 160 ms. Lower = less delay, more dropouts
}
