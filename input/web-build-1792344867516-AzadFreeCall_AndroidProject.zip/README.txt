AZAD FREE CALL — Android Studio project

This ZIP contains the full Gradle project structure (not an APK).
Upload this ZIP to a build service that accepts Android/Gradle source projects.
Root files must include settings.gradle.kts and build.gradle.kts.
Requires Android SDK 35 and JDK 17.

Important: This app uses Google Nearby Connections, which can use multiple nearby transports depending on Android/device support. The BLUETOOTH_ONLY flag in this source does not guarantee the library uses Bluetooth transport exclusively. Test with two real phones. Voice calling is experimental and has not been compiled or device-tested here.
