package com.azad.allinone

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071629)
private val Panel = Color(0xFF102B49)
private val Cyan = Color(0xFF16D9E8)
private val Violet = Color(0xFF9B87F5)
private val Emerald = Color(0xFF32D296)
private val Orange = Color(0xFFFFA94D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AzadApp() }
    }
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Default.Home),
    Diagnose("Diagnose", Icons.Default.HealthAndSafety),
    Doctor("AI Doctor", Icons.Default.AutoAwesome),
    History("History", Icons.Default.History),
    Settings("Settings", Icons.Default.Settings)
}

@Composable
private fun AzadApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("azad_preferences", Context.MODE_PRIVATE) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme", "System") ?: "System") }
    var accentName by remember { mutableStateOf(prefs.getString("accent", "Cyan") ?: "Cyan") }
    var selectedTab by remember { mutableStateOf(AppTab.Home) }
    val accent = when (accentName) {
        "Violet" -> Violet
        "Emerald" -> Emerald
        "Orange" -> Orange
        else -> Cyan
    }
    val dark = when (themeMode) {
        "Dark" -> true
        "Light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = accent, secondary = Cyan, background = Navy,
            surface = Panel, onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
        ) else lightColorScheme(
            primary = accent, secondary = Color(0xFF087E8B),
            background = Color(0xFFF4F8FC), surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    AppTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                AppTab.Home -> HomeScreen(accent, Modifier.padding(padding)) { selectedTab = it }
                AppTab.Diagnose -> DiagnoseScreen(accent, Modifier.padding(padding))
                AppTab.Doctor -> DoctorScreen(accent, Modifier.padding(padding))
                AppTab.History -> HistoryScreen(Modifier.padding(padding))
                AppTab.Settings -> SettingsScreen(
                    themeMode, accentName, Modifier.padding(padding),
                    onTheme = { themeMode = it; prefs.edit().putString("theme", it).apply() },
                    onAccent = { accentName = it; prefs.edit().putString("accent", it).apply() }
                )
            }
        }
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f))
    }
}

@Composable
private fun HomeScreen(accent: Color, modifier: Modifier = Modifier, navigate: (AppTab) -> Unit) {
    val context = LocalContext.current
    val battery = remember { batterySummary(context) }
    val storage = remember { storageSummary() }
    val network = remember { networkSummary(context) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(54.dp).background(Navy, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text("A", color = Cyan, fontSize = 32.sp, fontWeight = FontWeight.Black)
                }
                Column {
                    Text("AZAD ALL IN ONE", fontWeight = FontWeight.Black, fontSize = 20.sp, letterSpacing = 1.sp)
                    Text("Your futuristic mobile companion", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f), fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Cyan, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("SMART PHONE CENTER", color = Color.White.copy(alpha = .75f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("One app. Many solutions.", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Diagnose your phone, understand problems and get offline help.", color = Color.White.copy(alpha = .78f))
                    Button(onClick = { navigate(AppTab.Diagnose) }, colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Navy), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text("SCAN MY PHONE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Text("PHONE STATUS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusCard("Battery", battery, Icons.Default.BatteryChargingFull, accent, Modifier.weight(1f))
                StatusCard("Storage", storage, Icons.Default.Storage, accent, Modifier.weight(1f))
            }
        }
        item { StatusCard("Internet", network, Icons.Default.Wifi, accent, Modifier.fillMaxWidth()) }
        item {
            Text("ALL-IN-ONE TOOLS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolCard("AI Doctor", Icons.Default.AutoAwesome, accent, Modifier.weight(1f)) { navigate(AppTab.Doctor) }
                ToolCard("Phone care", Icons.Default.PhoneAndroid, accent, Modifier.weight(1f)) { navigate(AppTab.Diagnose) }
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, value: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(25.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .75f))
        }
    }
}

@Composable
private fun ToolCard(title: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text("Open tool", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
private fun DiagnoseScreen(accent: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var refreshed by remember { mutableIntStateOf(0) }
    val battery = remember(refreshed) { batterySummary(context) }
    val storage = remember(refreshed) { storageSummary() }
    val network = remember(refreshed) { networkSummary(context) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageTitle("Phone Diagnosis", "Quick local checks — works offline") }
        item { StatusCard("Battery & charging", battery, Icons.Default.BatteryChargingFull, accent, Modifier.fillMaxWidth()) }
        item { StatusCard("Storage", storage, Icons.Default.Storage, accent, Modifier.fillMaxWidth()) }
        item { StatusCard("Network", network, Icons.Default.NetworkCheck, accent, Modifier.fillMaxWidth()) }
        item {
            Button(onClick = { refreshed++ }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(8.dp)); Text("Refresh diagnostics")
            }
        }
        item { Text("These are basic indicators, not a complete hardware or battery-health test.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f)) }
    }
}

@Composable
private fun DoctorScreen(accent: Color, modifier: Modifier = Modifier) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf<String?>(null) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageTitle("AI Mobile Doctor", "Offline help now • online AI can be connected later") }
        item {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("What is wrong with your phone?", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = question, onValueChange = { question = it }, modifier = Modifier.fillMaxWidth(), minLines = 3,
                        label = { Text("Describe your problem") }, placeholder = { Text("Example: Wi-Fi connected but no internet") })
                    Button(onClick = { answer = offlineAnswer(question) }, modifier = Modifier.fillMaxWidth(), enabled = question.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Navy)) {
                        Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Find solution")
                    }
                }
            }
        }
        item {
            Text("Try a common problem", fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Wi-Fi connected but no internet", "Phone storage is full", "Phone is overheating", "Phone stuck on logo").forEach { prompt ->
                    OutlinedButton(onClick = { question = prompt; answer = offlineAnswer(prompt) }, modifier = Modifier.fillMaxWidth()) { Text(prompt) }
                }
            }
        }
        answer?.let { response ->
            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Suggested guidance", fontWeight = FontWeight.Bold, color = accent)
                        Text(response)
                    }
                }
            }
        }
        item { Text("This version uses a local troubleshooting library. Online AI requires a separately configured secure backend.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f)) }
    }
}

@Composable
private fun HistoryScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PageTitle("Diagnostic History", "Your scan history will appear here")
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.History, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                Text("No saved reports yet", fontWeight = FontWeight.Bold)
                Text("History storage is reserved for the next development milestone. Current diagnostics run locally.")
            }
        }
    }
}

@Composable
private fun SettingsScreen(themeMode: String, accentName: String, modifier: Modifier = Modifier, onTheme: (String) -> Unit, onAccent: (String) -> Unit) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageTitle("Personalize Azad", "Customize your futuristic app experience") }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp)); Text("Accent colour", fontWeight = FontWeight.Bold)
                    }
                    Text("Choose your signature colour")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cyan" to Cyan, "Violet" to Violet, "Emerald" to Emerald, "Orange" to Orange).forEach { (name, color) ->
                            Column(Modifier.weight(1f).clickable { onAccent(name) }.padding(vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(38.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
                                    if (accentName == name) Icon(Icons.Default.CheckCircle, null, tint = Navy)
                                }
                                Text(name, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Appearance", fontWeight = FontWeight.Bold)
                    Text("Select how Azad looks on your device")
                    listOf("System", "Dark", "Light").forEach { mode ->
                        Row(Modifier.fillMaxWidth().clickable { onTheme(mode) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(when (mode) { "Dark" -> Icons.Default.DarkMode; "Light" -> Icons.Default.LightMode; else -> Icons.Default.Settings }, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp)); Text(mode, modifier = Modifier.weight(1f))
                            RadioButton(selected = themeMode == mode, onClick = { onTheme(mode) })
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("AZAD ALL IN ONE", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Text("Version 1.0.0 • Futuristic mobile companion")
                    Text("Privacy-first design. Online AI is not enabled until a secure backend is configured.", fontSize = 12.sp)
                }
            }
        }
    }
}

private fun batterySummary(context: Context): String {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    if (level < 0 || scale <= 0) return "Battery information unavailable"
    val pct = level * 100 / scale
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    return "$pct% • " + if (charging) "Charging / full" else "Not charging"
}

private fun storageSummary(): String {
    return try {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        if (total <= 0) "Storage information unavailable"
        else {
            val usedPct = ((total - free) * 100 / total).toInt()
            "$usedPct% used • ${free / (1024 * 1024)} MB free"
        }
    } catch (_: Exception) { "Storage information unavailable" }
}

private fun networkSummary(context: Context): String {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "No active network"
        val caps = cm.getNetworkCapabilities(network) ?: return "Network status unavailable"
        val internet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        when {
            !internet -> "No internet-capable connection"
            !validated -> "Network connected • internet not validated"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi • internet available"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data • internet available"
            else -> "Internet connection available"
        }
    } catch (_: Exception) { "Network status unavailable" }
}

private fun offlineAnswer(raw: String): String {
    val q = raw.lowercase()
    return when {
        listOf("wifi", "wi-fi", "internet", "network").any { it in q } ->
            "1. Check whether another device can access the internet.\n\n2. Turn Wi-Fi off and on, then reconnect.\n\n3. If you control the router, restart it and wait for it to reconnect.\n\n4. If only this phone has the problem, review network settings. Avoid resetting settings unless you understand what will be erased."
        listOf("storage", "space", "memory", "full").any { it in q } ->
            "1. Open Android Settings → Storage.\n\n2. Review large videos, downloads and unused apps.\n\n3. Back up important data before deleting files.\n\n4. Do not delete unfamiliar system folders."
        listOf("hot", "heat", "overheat", "temperature").any { it in q } ->
            "1. Stop demanding apps and move the phone away from sunlight.\n\n2. If it is charging and unusually hot, disconnect power if safe.\n\n3. Never cool it with water or a refrigerator.\n\n4. If the battery swells, smoke appears or heat is extreme, stop using it and seek qualified service."
        listOf("logo", "boot", "start", "stuck").any { it in q } ->
            "1. Charge the phone with a known-good charger for a while.\n\n2. Try the manufacturer’s documented force-restart key combination.\n\n3. Avoid factory reset or wipe-data options if you need your files.\n\n4. If it remains stuck on the logo, seek model-specific support before erasing data."
        else ->
            "I could not confidently match this problem to an offline guide. Try describing the exact error message, phone model and what happened just before the issue. Online AI can be added later through a secure backend."
    }
}
