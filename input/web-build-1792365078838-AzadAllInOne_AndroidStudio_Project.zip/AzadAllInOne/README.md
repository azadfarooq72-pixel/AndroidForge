# AZAD ALL IN ONE — Android Studio Project

Native Kotlin + Jetpack Compose starter app.

## Important
This ZIP contains the Android Studio source project, not a ready-to-install APK.
It needs Android SDK 35, JDK 17, Android Gradle Plugin 8.10.1, and a compatible Gradle wrapper/build environment.
The AI Doctor uses offline troubleshooting guides; it does not call an online AI service.
